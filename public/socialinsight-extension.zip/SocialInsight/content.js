(() => {
  let lastSentHash = null;
  let debounceTimer = null;
  const DEBOUNCE_MS = 700;

  const simpleHash = str => {
    let h = 2166136261 >>> 0;
    for (let i = 0; i < str.length; i++) h = Math.imul(h ^ str.charCodeAt(i), 16777619);
    return (h >>> 0).toString(16);
  };

  // ---------------------------
  // Platform Detection
  // ---------------------------
  function detectPlatform() {
    const host = location.hostname;
    if (host.includes('twitter.com') || host.includes('x.com')) return 'twitter';
    if (host.includes('facebook.com')) return 'facebook';
    if (host.includes('tiktok.com')) return 'tiktok';
    if (host.includes('web.whatsapp.com')) return 'whatsapp';
    if (host.includes('reddit.com')) return 'reddit';
    if (host.includes('linkedin.com')) return 'linkedin';
    return 'unknown';
  }

  // ---------------------------
  // Extraction Functions (existing ones)
  // ---------------------------
  // [Insert all your extractXPostAndReplies() functions here: Twitter, FB, TikTok, LinkedIn, Reddit, WhatsApp]

function extractRedditPostAndReplies() {
    const result = { post: null, replies: [] };
    try {
      const postNode = document.querySelector('[data-test-id="post-content"]');
      if (postNode) {
        result.post = {
          displayName: postNode.querySelector('h3')?.innerText || '',
          username: postNode.querySelector('a[data-click-id="user"]')?.innerText || '',
          content: postNode.querySelector('div[data-click-id="text"]')?.innerText || '',
          counts: {}
        };
      }
      const replyNodes = document.querySelectorAll('[data-test-id="comment"]');
      replyNodes.forEach(node => {
        const contentNode = node.querySelector('div[data-testid="comment"]');
        const userNode = node.querySelector('a[data-click-id="user"]');
        if (contentNode && userNode) {
          result.replies.push({
            displayName: userNode.innerText,
            username: userNode.href || '',
            content: contentNode.innerText,
            counts: {}
          });
        }
      });
    } catch(e){ console.error('[Content] Reddit parse error', e); }
    return result;
  }

  // --- NEW: LinkedIn ---
  function extractLinkedInPostAndReplies() {
    const result = { post: null, replies: [] };
    try {
      const postNode = document.querySelector('div.feed-shared-update-v2');
      if (postNode) {
        result.post = {
          displayName: postNode.querySelector('span.feed-shared-actor__name')?.innerText || '',
          username: postNode.querySelector('a.feed-shared-actor__container-link')?.href || '',
          content: postNode.querySelector('div.feed-shared-update-v2__description')?.innerText || '',
          counts: {}
        };
      }
      const replyNodes = document.querySelectorAll('div.comments-comment-item');
      replyNodes.forEach(node => {
        const contentNode = node.querySelector('span.comment-text');
        const userNode = node.querySelector('span.feed-shared-actor__name');
        if (contentNode && userNode) {
          result.replies.push({
            displayName: userNode.innerText,
            username: '',
            content: contentNode.innerText,
            counts: {}
          });
        }
      });
    } catch(e){ console.error('[Content] LinkedIn parse error', e); }
    return result;
  }
  function extractTwitterPostAndReplies() {
  const result = { post: null, replies: [] };

  try {
    const tweetNodes = document.querySelectorAll('[data-testid="tweet"]');
    if (!tweetNodes.length) return result;

    // MAIN POST
    result.post = parseTweet(tweetNodes[0]);

    // REPLIES
    tweetNodes.forEach((node, i) => {
      if (i === 0) return;

      const parsed = parseTweet(node);
      if (!parsed) return;

      // filter out trash such as media-only nodes
      if (!parsed.content && !parsed.quoted) return;

      result.replies.push(parsed);
    });

  } catch (err) {
    console.error("[Content] extractPostAndReplies error", err);
  }


  return result;
}
function parseTweet(node) {
  try {
    if (!node) return null;

    // ----------- SOCIAL CONTEXT -----------
    const socialContext = node.querySelector('span[data-testid="socialContext"]')
      ?.innerText.trim() || null;

    const isRepost = socialContext?.toLowerCase().includes("reposted") || false;

    // ----------- MAIN TEXT -----------
    const contentNode = node.querySelector(':scope > div [data-testid="tweetText"]');
    let rawContent = contentNode?.innerText.trim() || null;

    // ----------- USER INFO -----------
    const userHref = node.querySelector(':scope a[href^="/"][role="link"]')
      ?.getAttribute("href");
    const username = userHref ? "@" + userHref.replace("/", "") : "";

    // ----------- DISPLAY NAME -----------
    let displayName = node.querySelector(':scope div[dir="ltr"] span')?.innerText.trim() || "";
    if (!displayName) {
      displayName = node.querySelector('[data-testid="User-Name"] span')?.innerText.trim() || "";
    }

    // ----------- COUNTS -----------
    const counts = {};
    node.querySelectorAll(':scope div[data-testid$="-count"]').forEach(c => {
      const key = c.getAttribute("data-testid").replace("-count", "");
      counts[key] = parseInt(c.innerText.replace(/\D/g, "")) || 0;
    });

    // ----------- QUOTED TWEET DETECTION -----------
    const quotedNode = findQuotedTweet(node);
    let quoted = null;

    if (quotedNode) {
      quoted = parseQuotedTweet(quotedNode);
    }

    // ----------- FIX CONTENT LOGIC -----------
    if (isRepost && (!rawContent || rawContent.length < 2)) {
      rawContent = null;
    }

    return {
      displayName,
      username,
      socialContext,
      isRepost,
      content: rawContent,
      quoted,
      counts
    };

  } catch (err) {
    console.error("parseTweet error", err);
    return null;
  }
}


function parseQuotedTweet(node) {
  const contentNode = node.querySelector('[data-testid="tweetText"]');
  const content = contentNode?.innerText.trim() || null;

  // ----------- DISPLAY NAME -----------
let displayName = "";
const userNameContainer = node.querySelector('[data-testid="User-Name"]');
if (userNameContainer) {
  const spanNodes = userNameContainer.querySelectorAll("span");
  for (let span of spanNodes) {
    const text = span.innerText.trim();
    if (text.startsWith("@")) {
      displayName = text;
      break;
    }
  }
}

// fallback to older selector
if (!displayName) {
  displayName = node.querySelector('div[dir="ltr"] span')?.innerText.trim() || "";
}

  const userHref = node.querySelector('a[href^="/"][role="link"]')
    ?.getAttribute("href");
  const username = userHref ? "@" + userHref.replace("/", "") : "";

  // nested quoted tweet
  const nestedNode = findQuotedTweet(node);
  let nested = null;

  if (nestedNode) {
    nested = parseQuotedTweet(nestedNode);
  }

  return {
    displayName,
    username,
    content,
    quoted: nested
  };
}
function findQuotedTweet(node) {
  if (!node) return null;

  // Look for potential quoted tweet text inside the current tweet
  const quotedTextNodes = node.querySelectorAll('[data-testid="tweetText"]');

  for (let i = 0; i < quotedTextNodes.length; i++) {
    const textNode = quotedTextNodes[i];

    // Skip if this is the main tweet's content
    if (textNode === node.querySelector('[data-testid="tweetText"]')) continue;

    // Find the nearest parent that also has a username/displayName
    let parent = textNode;
    while (parent && !parent.querySelector('[data-testid="User-Name"]')) {
      parent = parent.parentElement;
    }

    if (parent) return parent; // this is the quoted tweet container
  }

  return null;
}






  function extractFacebookPostAndReplies() {
    const result = { post: null, replies: [] };
    try {
      const postNode = document.querySelector('[role="article"]'); // first main post
      if (postNode) {
        const contentNode = postNode.querySelector('[data-ad-preview="message"]') || postNode.querySelector('div[dir="auto"]');
        const nameNode = postNode.querySelector('strong a') || postNode.querySelector('h2 span');
        if (contentNode && nameNode) {
          result.post = {
            displayName: nameNode.innerText.trim(),
            username: nameNode.href || '',
            content: contentNode.innerText.trim(),
            counts: {} // Facebook counts can be added later
          };
        }
      }

      const replyNodes = document.querySelectorAll('[role="article"]:not(:first-child)');
      replyNodes.forEach(node => {
        try {
          const contentNode = node.querySelector('[data-ad-preview="message"]') || node.querySelector('div[dir="auto"]');
          const nameNode = node.querySelector('strong a') || node.querySelector('h2 span');
          if (!contentNode || !nameNode) return;
          if (contentNode.innerText.trim().length > 5) {
            result.replies.push({
              displayName: nameNode.innerText.trim(),
              username: nameNode.href || '',
              content: contentNode.innerText.trim(),
              counts: {}
            });
          }
        } catch (e) { console.error('[Content] Facebook reply parse error', e); }
      });
    } catch (err) { console.error('[Content] extractFacebookPostAndReplies error', err); }
    return result;
  }
  function extractTikTokPostAndReplies() {
    const result = { post: null, replies: [] };
    try {
      const postNode = document.querySelector('div[data-e2e="main-post"]') || document.querySelector('div[class*="video-meta"]');
      if (postNode) {
        const contentNode = postNode.querySelector('h1, p') || postNode.querySelector('span');
        const nameNode = postNode.querySelector('h3 a') || postNode.querySelector('h2 span');
        if (contentNode && nameNode) {
          result.post = {
            displayName: nameNode.innerText.trim(),
            username: nameNode.href || '',
            content: contentNode.innerText.trim(),
            counts: {}
          };
        }
      }

      const replyNodes = document.querySelectorAll('div[data-e2e="comment-item"]');
      replyNodes.forEach(node => {
        try {
          const contentNode = node.querySelector('p, span');
          const nameNode = node.querySelector('h3 a, h4 span');
          if (!contentNode || !nameNode) return;
          if (contentNode.innerText.trim().length > 5) {
            result.replies.push({
              displayName: nameNode.innerText.trim(),
              username: nameNode.href || '',
              content: contentNode.innerText.trim(),
              counts: {}
            });
          }
        } catch (e) { console.error('[Content] TikTok reply parse error', e); }
      });
    } catch (err) { console.error('[Content] extractTikTokPostAndReplies error', err); }
    return result;
  }

  function extractWhatsAppPostAndReplies() {
    const result = { post: null, replies: [] };
    try {
      const chatNode = document.querySelector('[data-testid="conversation-panel-messages"]') || document.querySelector('#main');
      if (!chatNode) return result;

      const messages = chatNode.querySelectorAll('div[role="row"]');
      messages.forEach(node => {
        try {
          const contentNode = node.querySelector('span.selectable-text') || node.querySelector('div[dir="auto"]');
          const nameNode = node.querySelector('span[title]') || node.querySelector('h4 span');
          if (!contentNode || !nameNode) return;
          if (contentNode.innerText.trim().length > 0) {
            result.replies.push({
              displayName: nameNode.innerText.trim(),
              username: nameNode.title || '',
              content: contentNode.innerText.trim(),
              counts: {}
            });
          }
        } catch (e) { console.error('[Content] WhatsApp reply parse error', e); }
      });
    } catch (err) { console.error('[Content] extractWhatsAppPostAndReplies error', err); }
    return result;
  }

  // For brevity, we will assume all extraction functions exist here:
  function extractPostAndReplies() {
    const platform = detectPlatform();
    let data;
    switch(platform) {
      case 'twitter': data = extractTwitterPostAndReplies(); break;
      case 'facebook': data = extractFacebookPostAndReplies(); break;
      case 'tiktok': data = extractTikTokPostAndReplies(); break;
      case 'whatsapp': data = extractWhatsAppPostAndReplies(); break;
      case 'reddit': data = extractRedditPostAndReplies(); break;
      case 'linkedin': data = extractLinkedInPostAndReplies(); break;
      default: data = { post: null, replies: [] }; break;
    }
    return { ...data, platform };
  }

  // ---------------------------
  // Intelligent Auto-Scroll
  // ---------------------------
function intelligentAutoScroll(win, done, options = {}) {
  const {
    step = 1200,
    interval = 800,
    maxIdle = 5,
    forceInterval = false
  } = options;

  let lastHeight = 0;
  let idleCount = 0;

  const tick = () => {
    const height = document.documentElement.scrollHeight;

    win.scrollBy(0, step);

    if (height === lastHeight) {
      idleCount++;
    } else {
      idleCount = 0;
      lastHeight = height;
    }

    if (idleCount >= maxIdle) {
      clearInterval(timer);
      done();
    }
  };

  const timer = forceInterval
    ? setInterval(tick, interval)
    : setInterval(() => requestAnimationFrame(tick), interval);
}


  // Extract post/replies inside invisible window
  function extractPostAndRepliesFromWindow(win) {
    const platform = (() => {
  const host = win.location.hostname;
  if (host.includes('twitter.com') || host.includes('x.com')) return 'twitter';
  if (host.includes('facebook.com')) return 'facebook';
  if (host.includes('tiktok.com')) return 'tiktok';
  if (host.includes('reddit.com')) return 'reddit';
  if (host.includes('linkedin.com')) return 'linkedin';
  return 'unknown';
})();

    let data;
    switch(platform) {
      case 'twitter': data = win.extractTwitterPostAndReplies?.() || { post: null, replies: [] }; break;
      case 'facebook': data = win.extractFacebookPostAndReplies?.() || { post: null, replies: [] }; break;
      case 'tiktok': data = win.extractTikTokPostAndReplies?.() || { post: null, replies: [] }; break;
      case 'reddit': data = win.extractRedditPostAndReplies?.() || { post: null, replies: [] }; break;
      case 'linkedin': data = win.extractLinkedInPostAndReplies?.() || { post: null, replies: [] }; break;
      default: data = { post: null, replies: [] }; break;
    }
    return { ...data, platform };
  }

  // ---------------------------
  // Send Data
  // ---------------------------
  function sendData(data) {
    if (!data.post && data.replies.length === 0) return;

    const hash = simpleHash(JSON.stringify(data));
    if (hash === lastSentHash) return;
    lastSentHash = hash;

    chrome.runtime.sendMessage({
      action: 'POST_AND_REPLIES_CAPTURED',
      url: location.href,
      data
    });
  }

  // ---------------------------
  // Message Listener
  // ---------------------------
  if (!window._insight_listener_registered) {
    window._insight_listener_registered = true;

    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (msg.action === 'CAPTURE_NOW') {
        const data = extractPostAndReplies();
        sendData(data);
        sendResponse({ success: !!data.post, data: { ...data, url: location.href } });
        return true;
      }
      if (msg.action === 'START_AUTO_CAPTURE') {
        
        sendResponse({success:true, url: location.href  });
        return true;
      }

if (msg.action === 'AUTO_CAPTURE') {
  const platform = detectPlatform();

  /* ---------------- WHATSAPP (foreground tab) ---------------- */
  if (platform === 'whatsapp') {
    const container =
      document.querySelector('[data-testid="conversation-panel-messages"]') ||
      document.querySelector('#main') ||
      document.body;

    intelligentAutoScroll(container, () => {
      const data = extractWhatsAppPostAndReplies();
      sendData(data); // 
      sendResponse({ success: true });
    });

    return true;
  }

  /* ---------------- X / TWITTER (popup or background window) ---------------- */
  if (platform === 'twitter') {
    intelligentAutoScroll(window, () => {
      const data = extractTwitterPostAndReplies();
      sendData(data); // 
      sendResponse({ success: true });
    }, {
      forceInterval: true // 🔑 REQUIRED for opened/background window
    });

    return true;
  }

  /* ---------------- OTHER PLATFORMS (background window) ---------------- */
  let container;

  switch (platform) {
    case 'facebook':
      container = document.querySelector('[role="feed"]');
      break;
    case 'linkedin':
      container = document.querySelector('div.feed-shared-update-v2');
      break;
    case 'tiktok':
      container = document.querySelector('div[data-e2e="comment-list"]');
      break;
    case 'reddit':
      container = document.querySelector('div[data-test-id="comment"]');
      break;
    default:
      container = document.body;
  }

  intelligentAutoScroll(container || window, () => {
    const data = extractPostAndReplies();
    sendData(data); //
    sendResponse({ success: true });
  }, {
    forceInterval: true // 
  });

  return true;
}

    });
  }

  // ---------------------------
  // Debounced Live Capture
  // ---------------------------
 /* const observer = new MutationObserver(() => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      const data = extractPostAndReplies();
      sendData(data);

    }, DEBOUNCE_MS);
  });

  observer.observe(document.body, { childList: true, subtree: true });*/
 
})();

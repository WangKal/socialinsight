// popup.js
 
document.addEventListener("DOMContentLoaded", async () => {
await updateRecentActivity();
});

async function updateRecentActivity() {
  const container = document.querySelector(".analytics-list");
  if (!container) return;

  chrome.runtime.sendMessage({ type: "FETCH_RECENT_POLLS" }, (response) => {
    const posts = response?.polls || [];
 

    if (!posts.length) {
      container.innerHTML = defaultGlobalActivityHTML();
      return;
    }

    container.innerHTML = "";

    posts.forEach((item) => {
      const id = item.id || item.post_id || "N/A";
      const poster = item.post_text?.displayName || "Unknown Poster";
      const postText = item.analysis_result?.post?.text || "No post text available";
      const postType = item.analysis_result?.post?.detected_post_type || "Not classified";
      const totalReplies =
        item.analysis_result?.statistics?.total_replies ||
        item.total_replies ||
        0;

      const card = document.createElement("div");
      card.className = "analytics-card";
      card.dataset.postId = id; // clickable reference

      card.innerHTML = `
        <div class="card-content">
          <div class="card-text">

            <h3 class="card-title">
              <strong>${poster}</strong>
            </h3>

            <p class="post-preview" style="opacity: 0.85;">
              ${truncate(postText, 120)}
            </p>

            <p class="card-description">
              <span>
              Type: <strong>${postType}</strong> • 
              Replies: <strong>${totalReplies}</strong>
            </p>

          </div>
          ${arrowIcon()}
        </div>
      `;

      container.appendChild(card);

      // Allow clicking to fetch entire post later
      card.addEventListener("click", async () => {
  await showReplies(card.dataset.postId);
});

    });
  });
}

function arrowIcon() {
  return `
    <svg class="icon-link" width="16" height="16" viewBox="0 0 24 24" fill="none"
      stroke="currentColor" stroke-width="2">
      <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
      <polyline points="15 3 21 3 21 9"></polyline>
      <line x1="10" y1="14" x2="21" y2="3"></line>
    </svg>
  `;
}

function truncate(text, max) {
  return text.length > max ? text.substring(0, max) + "..." : text;
}


// GLOBAL default analytics to show when user has no polls
function defaultGlobalActivityHTML() {
  return `
    <div class="analytics-card">
      <div class="card-content">
        <div class="card-text">
          <h3 class="card-title">No Recent Analysis</h3>
          <p class="card-description">Start your first analysis to see insights here.</p>
        </div>
        ${arrowIcon()}
      </div>
    </div>

    <div class="analytics-card">
      <div class="card-content">
        <div class="card-text">
          <h3 class="card-title">Tip: Highlight Better</h3>
          <p class="card-description">Highlight a post to generate instant analytics.</p>
        </div>
        ${arrowIcon()}
      </div>
    </div>

    <div class="analytics-card">
      <div class="card-content">
        <div class="card-text">
          <h3 class="card-title">AI Insights Ready</h3>
          <p class="card-description">Your next analysis will appear here automatically.</p>
        </div>
        ${arrowIcon()}
      </div>
    </div>

    <div class="analytics-card">
      <div class="card-content">
        <div class="card-text">
          <h3 class="card-title">Need Help?</h3>
          <p class="card-description">Use the extension on X, WhatsApp, TikTok, Reddit, LinkedIn, Instagram or Facebook.</p>
        </div>
        ${arrowIcon()}
      </div>
    </div>
  `;
}

document.addEventListener('DOMContentLoaded', () => {
  const statusHolder = document.getElementById('status-container');
  const statusMessage = document.getElementById('statusMessage');
  const progressBar = document.getElementById('progressBar');
  
  const creditsRemaining = document.getElementById('creditsRemaining');
  const buyCredits = document.getElementById('buyCredits');

  // Simulated credits
  //creditsRemaining.innerText = 5;

  const updateStatus = (msg, progress = null, status = null,color = "blue") => {
   statusHolder.style.display ="block"
    statusMessage.innerText = msg;
    if (progress !== null) {
      progressBar.style.display = 'block';
       progressBar.style.color = color;
      progressBar.style.width = progress;
    } else {
      progressBar.style.display = 'none';
    }

    setInterval(()=>{
      statusHolder.style.display ="none"
       progressBar.style.display = 'none';
      },5000)
  };


function parseResponse(res){
const data = res.data;
// Parse deeply nested content
let postData = {};
try { postData = JSON.parse(data.post_text); } catch {}

// Extract analysis fields
const analysis = data.analysis_result || {};
const post = analysis.post || {};
const groups = analysis.groups || {};
const replies = analysis.replies || [];
const stats = analysis.statistics || {};
const topicClusters = analysis.topic_clusters || [];

queueContainer.innerHTML = "";

/* ----------------------------------------------
   🟦 POST HEADER CARD (FULL CHAIN: repost + quote)
------------------------------------------------- */
function renderTweetChain(node) {
  if (!node) return "";

  return `
    <div class="tweet-block">
      <div class="tweet-author"><strong>${node.displayName || ""}</strong> <span>${node.username || ""}</span></div>
      <div class="tweet-content">${node.content || ""}</div>
      ${node.quoted ? `<div class="tweet-quoted">${renderTweetChain(node.quoted)}</div>` : ""}
    </div>
  `;
}

const postCard = document.createElement("div");
postCard.className = "analytics-card";
postCard.innerHTML = `
  <h3 class="card-title">Post Overview</h3>

  ${postData.isRepost ? `<div class="tag tag-repost">Repost</div>` : ""}
  
  <div class="original-post">
    ${renderTweetChain(postData)}
  </div>

  <p class="card-description">
    <strong>Detected Type:</strong> ${post.detected_post_type || "Unknown"}<br>
  </p>
`;
queueContainer.appendChild(postCard);

/* ----------------------------------------------
   🟩 AGREEMENT DISTRIBUTION BAR
------------------------------------------------- */
if (stats.agreement_distribution) {
  const ag = stats.agreement_distribution;
  const bar = document.createElement("div");
  bar.className = "analytics-card";
  bar.innerHTML = `
    <h3 class="card-title">Agreement Distribution</h3>
    <div class="stack-bar">
      <div class="bar agree"   style="width:${ag.agree || 0}%"></div>
      <div class="bar neutral" style="width:${ag.neutral || 0}%"></div>
      <div class="bar disagree" style="width:${ag.disagree || 0}%"></div>
    </div>
    <p class="bar-labels">
      Agree: ${ag.agree || 0}% • Neutral: ${ag.neutral || 0}% • Disagree: ${ag.disagree || 0}%
    </p>
  `;
  queueContainer.appendChild(bar);
}

/* ----------------------------------------------
   🟥 SENTIMENT DISTRIBUTION BAR
------------------------------------------------- 
if (stats.sentiment_distribution) {
  const s = stats.sentiment_distribution;
  const bar = document.createElement("div");
  bar.className = "analytics-card";
  bar.innerHTML = `
    <h3 class="card-title">Sentiment Distribution</h3>
    <div class="stack-bar">
      <div class="bar negative" style="width:${s.negative || 0}%"></div>
      <div class="bar neutral"  style="width:${s.neutral || 0}%"></div>
      <div class="bar positive" style="width:${s.positive || 0}%"></div>
    </div>
    <p class="bar-labels">
      Negative: ${s.negative || 0}% • Neutral: ${s.neutral || 0}% • Positive: ${s.positive || 0}%
    </p>
  `;
  queueContainer.appendChild(bar);
}*/

/* ----------------------------------------------*/
["agree", "neutral", "disagree"].forEach(key => {
      const grp = groups[key] || {};

      const card = document.createElement("div");
      card.className = "analytics-card";

      card.innerHTML = `
        <h3 class="card-title">${key.toUpperCase()}</h3>
        <p>${grp.summary || ""}</p>

        <div class="progress-bar-container">
          <div class="progress-bar" style="width:${grp.percentage || 0}%"></div>
        </div>
      `;

      queueContainer.appendChild(card);
    });


/* ----------------------------------------------
   🟧 AGREEMENTS SECTION — TABS + REPLIES
------------------------------------------------- */
(() => {
  const wrapper = document.createElement("div");
  wrapper.className = "analytics-card";

  wrapper.innerHTML = `
    <h3 class="card-title">Agreement Breakdown</h3>

    <div class="tab-group">
      <button class="tab-btn active" data-tab="agree-tab">Agree</button>
      <button class="tab-btn" data-tab="neutral-tab">Neutral</button>
      <button class="tab-btn" data-tab="disagree-tab">Disagree</button>
    </div>

    <div id="agree-tab" class="tab-panel active"></div>
    <div id="neutral-tab" class="tab-panel"></div>
    <div id="disagree-tab" class="tab-panel"></div>
  `;

  queueContainer.appendChild(wrapper);

  // Separate replies correctly
  const agreeReplies = replies.filter(r => r.agreement === "agree");
  const neutralReplies = replies.filter(r => r.agreement === "neutral");
  const disagreeReplies = replies.filter(r => r.agreement === "disagree");

  function renderReply(div, r) {
    const item = document.createElement("div");
    item.className = "reply-item small";
    item.innerHTML = `
      <p><strong>${r.user}</strong>: ${r.text}</p>
      <p class="reply-meta-small">Sentiment: ${r.sentiment} • Tone: ${r.tone}</p>
    `;
    div.appendChild(item);
  }

  function renderReplies(div, arr) {
    if (!arr.length) {
      const msg = document.createElement("div");
      msg.className = "reply-item small";
      msg.innerHTML = `<p><em>No replies</em></p>`;
      div.appendChild(msg);
    } else {
      arr.forEach(r => renderReply(div, r));
    }
  }

  renderReplies(wrapper.querySelector("#agree-tab"), agreeReplies);
  renderReplies(wrapper.querySelector("#neutral-tab"), neutralReplies);
  renderReplies(wrapper.querySelector("#disagree-tab"), disagreeReplies);

  // Tab switching
  wrapper.querySelectorAll(".tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      wrapper.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
      wrapper.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));

      btn.classList.add("active");
      wrapper.querySelector(`#${btn.dataset.tab}`).classList.add("active");
    });
  });
})();

/* ----------------------------------------------
   🟦 CLUSTERS SECTION USING GROUPS
------------------------------------------------- */
(() => {
  const wrap = document.createElement("div");
  wrap.className = "analytics-card";

  wrap.innerHTML = `
    <h3 class="card-title">Clusters by Agreement</h3>

    <div class="tab-group">
      <button class="tab-btn active" data-clustertab="c-agree">Agree</button>
      <button class="tab-btn" data-clustertab="c-neutral">Neutral</button>
      <button class="tab-btn" data-clustertab="c-disagree">Disagree</button>
    </div>

    <div id="c-agree" class="tab-panel active"></div>
    <div id="c-neutral" class="tab-panel"></div>
    <div id="c-disagree" class="tab-panel"></div>
  `;

  queueContainer.appendChild(wrap);

  function renderCluster(container, cluster) {
    const box = document.createElement("div");
    box.className = "cluster-box";

    const clusterId = "cl-" + cluster.cluster_id;

    box.innerHTML = `
      <div class="cluster-header" data-target="${clusterId}">
        <strong>${cluster.topic}</strong>  
        <span class="count">(${cluster.replies.length})</span>
        <span class="caret">▸</span>
      </div>

      <div id="${clusterId}" class="cluster-replies hidden"></div>
    `;

    const repliesDiv = box.querySelector(`#${clusterId}`);
    if (!cluster.replies || !cluster.replies.length) {
      const msg = document.createElement("div");
      msg.className = "reply-item small";
      msg.innerHTML = `<p><em>No replies in this cluster</em></p>`;
      repliesDiv.appendChild(msg);
    } else {
      cluster.replies.forEach(r => {
        const item = document.createElement("div");
        item.className = "reply-item small";
        item.innerHTML = `
          <p><strong>${r.user}</strong>: ${r.text}</p>
          <p class="reply-meta-small">
            Sentiment: ${r.sentiment} • Agreement: ${r.agreement} • Tone: ${r.tone}
          </p>
        `;
        repliesDiv.appendChild(item);
      });
    }

    container.appendChild(box);
  }

  // Loop through each agreement group
  ["agree", "neutral", "disagree"].forEach(groupKey => {
    const group = groups[groupKey] || {};
    const panel = wrap.querySelector(`#c-${groupKey}`);

    // Render clusters in this group
    if (!group.clusters || !group.clusters.length) {
      const msg = document.createElement("div");
      msg.className = "reply-item small";
      msg.innerHTML = `<p><em>No clusters in this group</em></p>`;
      panel.appendChild(msg);
    } else {
      group.clusters.forEach(cluster => renderCluster(panel, cluster));
    }
  });

  // Tab switching
  wrap.querySelectorAll(".tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      wrap.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
      wrap.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));

      btn.classList.add("active");
      wrap.querySelector(`#${btn.dataset.clustertab}`).classList.add("active");
    });
  });

  // Dropdown expand/collapse with caret rotation
  wrap.querySelectorAll(".cluster-header").forEach(header => {
    header.addEventListener("click", () => {
      const target = document.getElementById(header.dataset.target);
      const caret = header.querySelector(".caret");
      target.classList.toggle("hidden");
      caret.textContent = target.classList.contains("hidden") ? "▸" : "▾";
    });
  });
})();



/* ----------------------------------------------
   🟪 REPLIES LIST
------------------------------------------------- */
if (replies.length) {
  const repliesCard = document.createElement('div');
  repliesCard.className = 'analytics-card';
  repliesCard.innerHTML = `<h3 class="card-title">Replies (${replies.length})</h3>`;

  replies.forEach(r => {
    const item = document.createElement('div');
    item.className = 'reply-item';
    item.innerHTML = `
      <p><strong>${r.user}</strong>: ${r.text}</p>
      <p class="reply-meta">
        Sentiment: ${r.sentiment || '-'} • 
        Agreement: ${r.agreement || '-'} • 
        Tone: ${r.tone || '-'}
      </p>
    `;
    repliesCard.appendChild(item);
  });

  queueContainer.appendChild(repliesCard);
  const to_site = document.createElement('div');
  to_site.className = 'site-link';
    to_site.innerHTML = `
      <a href="#"><strong>Full site comprehensive view</a>
      
    `;
    queueContainer.appendChild(to_site);
}


 } 

async function showReplies (analysis_id = null){
  document.getElementById('loaderOverlay').classList.add("active")
  
 let queueContainer = document.getElementById('queueContainer');
  queueContainer.innerHTML = ''; // clear previous content
let r_a = await chrome.storage.local.get("recent-analysis");
let analysisId = (analysis_id == null ? r_a["recent-analysis"] : analysis_id);

  if (analysisId == null || !analysisId) {
   // queueContainer.innerText = 'No Analysis ID available.';
     updateStatus('No Recent Analysis available.',100,"orange");

     document.getElementById('loaderOverlay').classList.remove("active")
    return;
  }

  // Ask background.js to fetch data from Supabase
  chrome.runtime.sendMessage({ action: 'FETCH_ANALYSIS', analysisId }, (res) => {




if (!res.ok || !res.data) {
  //queueContainer.innerText = 'No replies captured yet.';
  updateStatus('No replies captured yet.',100,"orange");
  document.getElementById('loaderOverlay').classList.remove("active")
  return;
}
parseResponse(res);
document.getElementById('loaderOverlay').classList.remove("active")
updateStatus('Analysis complete.',100,"orange");

})
}



// Add this somewhere in your popup script, before calling captureNow
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === "ANALYSIS_UPDATE" && msg.analysis_id) {
   

    if (msg.status === "completed") {
      // Final result available
      const res = {data:msg.result}
      parseResponse(res); // <-- capture result here
      updateStatus('Analysis complete.', 100, "green");
      document.getElementById('loaderOverlay').classList.remove("active");
    } else if (msg.status === "failed") {
      updateStatus('Analysis failed.', 100, "red");
      document.getElementById('loaderOverlay').classList.remove("active");
    } else {
      // Optional: intermediate status
      updateStatus(`Analysis in progress... (${msg.status})`, 50, "blue");
    }
  }
});



  // --- Auto (Headless) ---
  document.getElementById('autoCapture').addEventListener('click', () => {
    updateStatus('Auto capture will run in the background.',null,"blue");
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    chrome.tabs.sendMessage(tabs[0].id, { action: 'START_AUTO_CAPTURE'}, (resp) => {

      if (resp?.success) {
        
chrome.runtime.sendMessage({ 
          action: 'CREATE_WINDOW', 
          url: resp.url, 
        }, (res) => {

/*

        // Trigger backend save and polling via background
        chrome.runtime.sendMessage({ 
          action: 'POST_AND_REPLIES_CAPTURED', 
          url: res.data.url,
          data: res.data 
        }, (res2) => {
          if (!res2.ok) {
            updateStatus('Failed to queue analysis. Try again.', 100, "orange");
            document.getElementById('loaderOverlay').classList.remove("active");
            return;
          }

          // At this point, background has started polling.
          // The actual result will be received asynchronously via ANALYSIS_UPDATE listener above.
          updateStatus('Analysis queued. Waiting for AI results...', 50, "blue");
        });
*/
      })

      } else {
        updateStatus('Failed to capture. Scroll further or try again.', 100, "red");
      }

    });
  });
  });

// Capture post & replies
document.getElementById('captureNow').addEventListener('click', () => {
  document.getElementById('loaderOverlay').classList.add("active");
  updateStatus('Capturing post and replies...', null, "blue");

  chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
    chrome.tabs.sendMessage(tabs[0].id, { action: 'CAPTURE_NOW' }, (resp) => {

      if (resp?.success) {
        updateStatus(
          `Captured ${resp.data.replies.length} replies from ${resp.data.platform}. Wait for AI Analysis...`,
          100,
          "green"
        );

        // Trigger backend save and polling via background
        chrome.runtime.sendMessage({ 
          action: 'POST_AND_REPLIES_CAPTURED', 
          url: resp.data.url,
          data: resp.data 
        }, (res) => {
          if (!res.ok) {
            updateStatus('Failed to queue analysis. Try again.', 100, "orange");
            document.getElementById('loaderOverlay').classList.remove("active");
            return;
          }

          // At this point, background has started polling.
          // The actual result will be received asynchronously via ANALYSIS_UPDATE listener above.
          updateStatus('Analysis queued. Waiting for AI results...', 50, "blue");
        });

      } else {
        document.getElementById('loaderOverlay').classList.remove("active");
        updateStatus('Failed to capture. Scroll further or try again.', 100, "red");
      }

    });
  });
});

// --- Show Replies ---

document.getElementById('showReplies').addEventListener('click', async () => {
        await showReplies();
      });
  
;
// --- Listen for realtime updates from background ---
/*chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === 'ANALYSIS_UPDATE') {
    const { url, status,result } = msg;
    if (status === 'analyzing') {
      updateStatus(`Analysis running for ${url}...`,50,"green");
      progressBar.style.display = 'block';
    } else if (status === 'complete' ) {
      //progressBar.style.display = 'none';
      updateStatus(`Analysis complete for ${url}`,100,"green");
      parseResponse(msg.result)
      // Optionally refresh showReplies
     // document.getElementById('showReplies').click();
    }else if (status === 'complete' || status === 'failed') {
      //progressBar.style.display = 'none';
      updateStatus(`Analysis failed for ${url}`,100,"red");
      // Optionally refresh showReplies
      
      //document.getElementById('showReplies').click();
    }
    
  }
});*/

  // --- Buy Credits ---
 /* buyCredits.addEventListener('click', () => {
    const url = 'https://yourextensionwebsite.com/buy-credits';
    chrome.tabs.query({ url }, (tabs) => {
      if (tabs.length) {
        chrome.tabs.update(tabs[0].id, { active: true });
      } else {
        chrome.tabs.create({ url });
      }
    });
  });*/


document.getElementById("buyCreditsBtn").addEventListener("click", async () => { 
  const stored = await chrome.storage.local.get(["jwt", "supabase"]);
  const internalJwt = stored.jwt;
  const userId = stored.supabase?.user?.id;
  const supaAccessToken = stored.supabase?.access_token;
  const supaRefreshToken = stored.supabase?.refresh_token;

  if (!internalJwt || !userId || !supaAccessToken) {
    alert("Authentication missing. Please sign in again.");
    return;
  }

  // Generate redirect link from backend
  const resp = await fetch("https://socialinsightbackend.onrender.com/api/auth_app/verify_user/", {
    method: "POST",
    headers: { 
      "Content-Type": "application/json",
      "Authorization": `Bearer ${internalJwt}`
    },
    body: JSON.stringify({
      user_id: userId,
      supabase_token: supaAccessToken,
      supabase_refresh: supaRefreshToken
    })
  });

  const json = await resp.json();

  // Redirect user to YOUR payment page (not Paystack directly)
  window.open(json.redirect_url, "_blank");
});


});


//--Auth Fn --
async function checkAuthState() {



  const { jwt, temp_jwt, supabase } = await chrome.storage.local.get(["jwt", "temp_jwt", "supabase"]);

  // --- Normal login: JWT + Supabase access token ---
  if (jwt && supabase?.access_token) {
    // Optional: check expiry timestamp in Supabase session
    const now = Math.floor(Date.now() / 1000); // seconds
    if (!supabase.expires_at || supabase.expires_at > now) {
      showDashboard();
      document.getElementById("user-account").innerText = supabase.user.email
      document.getElementById("logout-btn").innerText = "Log In"
       await updateRecentActivity();
      return;
    }
  }

  // --- Pending signup auto-complete ---
  if (temp_jwt) {
    try {
      const res = await fetch("https://socialinsightbackend.onrender.com/api/auth_app/complete_signup/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ temp_jwt })
      });
      const data = await res.json();

      if (data.jwt && data.supabase_session) {
        // Save returned session & JWT
        setStorage("jwt", data.jwt);
        setStorage("supabase", data.supabase_session);
        document.getElementById("user-account").innerText = data.supabase_session.user.email
        document.getElementById("logout-btn").innerText = "Log In"

        // Remove temp_jwt after successful login
        chrome.storage.local.remove("temp_jwt");

        showDashboard();
         await updateRecentActivity();
        return;
      } else {
        console.warn("Pending signup could not complete:", data);
      }
    } catch (err) {
      console.error("Complete signup failed:", err);
    }
  }

  // --- Default: show auth screen ---
  showLoginScreen();
}



checkAuthState();

// Helper to get/set storage
function setStorage(key, value) {
  chrome.storage.local.set({ [key]: value });
}

function getStorage(key) {
  return new Promise(resolve => chrome.storage.local.get([key], result => resolve(result[key])));
}

function clearStorage(keys) {
  chrome.storage.local.remove(keys);
}

// -------------------
// LOGIN / SIGNUP
// -------------------
async function loginUser(email, password) {
  const loader = document.getElementById("loaderOverlay");
  const loginBtn = document.getElementById("login-btn");

  try {
    // Show loader + disable button
    loader.classList.add("active");
    loginBtn.disabled = true;
    loginBtn.innerText = "Logging in...";

    showLoginStatus("Authenticating...", "#0d6efd");

    const res = await fetch("https://socialinsightbackend.onrender.com/api/auth_app/login/", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ email, password })
    });

    const data = await res.json();

    if (!res.ok) {
      showLoginStatus(data.error || "Login failed", "red");
      return;
    }

    if (data.jwt && data.supabase_session) {
      await setStorage("jwt", data.jwt);
      await setStorage("supabase", data.supabase_session);

      // UI update
      showLoginStatus("Logged in successfully!", "green");

      document.getElementById("user-account").innerText = email;
      document.getElementById("logout-btn").innerText = "Log Out";

      showDashboard();
      await updateRecentActivity();
      loadCredits();

    } else {
      showLoginStatus("Invalid login response.", "red");
    }

  } catch (err) {
    console.error("Login error", err);
    showLoginStatus("Network error. Try again.", "red");

  } finally {
    // Hide loader + reset button
    loader.classList.remove("active");
    loginBtn.disabled = false;
    loginBtn.innerText = "Log In";
  }
}


 async function signupUser(company, name, email, password) {
  const loader = document.getElementById("loaderOverlay");
  const signupBtn = document.getElementById("signup-btn");

  // Check terms checkbox
  if (!document.getElementById("terms").checked) {
    showSignupStatus("Please accept Terms & Privacy Policy.", "red");
    return;
  }

  try {
    // UI: activate loader + disable button
    loader.classList.add("active");
    signupBtn.disabled = true;
    signupBtn.innerText = "Creating account...";
    showSignupStatus("Processing signup...", "#0d6efd");

    const res = await fetch("https://socialinsightbackend.onrender.com/api/auth_app/signup/", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({ company, name, email, password })
    });

    const data = await res.json();
 ;

    if (!res.ok) {
      showSignupStatus(data.error || "Signup failed.", "red");
      return;
    }

    if (data.jwt) {
      await setStorage("temp_jwt", data.jwt);

      showSignupStatus("Account created! Please check your email for confirmation.", "green");

      // Show already-confirmation section if you have it
      const confirmBox = document.getElementById("email-confirmation");
      if (confirmBox) confirmBox.style.display = "block";

    } else {
      showSignupStatus("Signup failed. Try again.", "red");
    }

  } catch (err) {
    console.error("Signup error", err);
    showSignupStatus("Network error. Try again.", "red");

  } finally {
    // UI reset
    loader.classList.remove("active");
    signupBtn.disabled = false;
    signupBtn.innerText = "Sign Up";
  }
}


// -------------------
// GOOGLE OAUTH
// -------------------
function googleLogin() {
  // Redirect the extension to backend OAuth endpoint
  window.location.href = "https://socialinsightbackend.onrender.com/api/auth_app/google/";
}

// Handle callback (e.g., extension URL: chrome-extension://<id>/auth)
async function handleOAuthCallback(queryString) {
  const params = new URLSearchParams(queryString);
  const jwt = params.get("jwt");
  const supabase_access = params.get("supabase_access");
  const supabase_refresh = params.get("supabase_refresh");

  if (jwt && supabase_access) {
    setStorage("jwt", jwt);
    setStorage("supabase", { access_token: supabase_access, refresh_token: supabase_refresh });
    showDashboard();
  }
}

// -------------------
// TOKEN EXCHANGE (optional)
// -------------------
async function exchangeSupabaseToken() {
  const supabase = await getStorage("supabase");
  if (!supabase?.access_token) return;

  try {
    const res = await fetch("https://socialinsightbackend.onrender.com/api/auth_app/exchange_token/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ supabase_token: supabase.access_token })
    });
    const data = await res.json();
    if (data.jwt) setStorage("jwt", data.jwt);
  } catch (err) {
    console.error("Token exchange failed", err);
  }
}

// -------------------
// LOGOUT
// -------------------
async function logout() {
  const supabase = await getStorage("supabase");
  try {
    if (supabase?.access_token) {
      await fetch("https://socialinsightbackend.onrender.com/api/auth_app/logout/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ supabase_access_token: supabase.access_token })
      });
    }
  } catch (err) {
    console.error("Logout error", err);
  } finally {
    clearStorage(["jwt", "supabase"]);
  
    showLoginScreen();
    showSignupStatus("Successfully signed out! .Hope to see you soon", "green");

  }
}


function showLoginStatus(message, color="black") {
  const s = document.getElementById("login-status");
  s.innerText = message;
  s.style.color = color;
   setInterval(()=>{
      s.innerText = "";
      },10000)
}
function showSignupStatus(message, color="black") {
  const s = document.getElementById("signup-status");
  s.innerText = message;
  s.style.color = color;
  setInterval(()=>{
      s.innerText = "";
      },10000)
}

// -------------------
// UI SWITCHING
// -------------------

// For AUTH 
document.getElementById("show-signup").addEventListener("click", () => {
  document.querySelector(".flip-card").classList.add("flipped");
});

document.getElementById("show-login").addEventListener("click", () => {
  document.querySelector(".flip-card").classList.remove("flipped");
});

//To Dashboard
function showDashboard() {
  document.querySelector(".login-section").style.display = "none";
  document.querySelector(".extension-popup").style.display = "block";
}

function showLoginScreen() {
  document.querySelector(".login-section").style.display = "block";
  document.querySelector(".extension-popup").style.display = "none";
}

// -------------------
// EVENT LISTENERS
// -------------------
document.getElementById("login-btn").addEventListener("click", async () => {
  const email = document.getElementById("login-email").value.trim();
  const password = document.getElementById("login-password").value;

  if (!email || !password) {
    showLoginStatus("Please enter email and password.", "red");
    return;
  }

  await loginUser(email, password);
});


document.getElementById("signup-btn").addEventListener("click", async () => {
  const company = document.getElementById("signup-company").value.trim();
  const name = document.getElementById("signup-name").value.trim();
  const email = document.getElementById("signup-email").value.trim();
  const password = document.getElementById("signup-password").value;

  if (!name || !email || !password) {
    showSignupStatus("Ensure name , email and password fields are required.", "red");
    return;
  }

  await signupUser(company, name, email, password);
});


//document.getElementById("google-login-btn").addEventListener("click", googleLogin);
document.getElementById("logout-btn").addEventListener("click", logout);


// On popup load: check if callback from OAuth
if (window.location.href.includes("auth?")) {
  handleOAuthCallback(window.location.search);
}
/** Credits **/
async function loadCredits() {
  const supabase = await getStorage("supabase");
  const jwt = await getStorage("jwt");
  if (!supabase.user.id) return;
  try {
    if (supabase?.access_token) {
     const res = await fetch("https://socialinsightbackend.onrender.com/api/payments/get_credits/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({jwt:jwt,user_id:supabase.user.id, supabase_access_token: supabase.access_token })
      });
      const data = await res.json();
        document.getElementById("credits-amount").innerText = data.credits;

    }
  } catch (err) {
    console.error("Credits error", err);
  } 
 

}
